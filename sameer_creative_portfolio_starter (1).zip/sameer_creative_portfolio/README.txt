SAMEER BASHA — CREATIVE PORTFOLIO
=================================

Included:
- index.html — the complete responsive website (HTML, CSS and JavaScript in one file).

RUN IT ON YOUR COMPUTER
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html. It should open in your browser.
4. To edit it, open index.html in VS Code or Notepad.

IMPORTANT BEFORE PUBLISHING
1. Search in index.html for YOUR_EMAIL@example.com and replace it with your professional email address.
2. Review your introduction and project descriptions.
3. Keep concept projects clearly labelled as practice/speculative work. Do not imply that a brand hired you.
4. Only add phone number, social links or client claims if you want them public and they are accurate.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, for example: sameer-creative-portfolio
3. Upload index.html to the repository's root (top level).
4. Open the repository Settings → Pages.
5. Under build/deployment, select “Deploy from a branch”; choose branch “main” and folder “/(root)”, then Save.
6. Wait for the deployment to finish. GitHub will show the published website URL in Settings → Pages.
7. Open that URL and test it on both laptop and phone.

Alternative: Netlify Drop
- Visit https://app.netlify.com/drop and drop the extracted website folder there. Follow the site's current prompts. A free account may be required.

COST
- This website code is free. GitHub Pages can host a public static site at no charge.
- A custom domain is optional and costs extra; do not buy one yet.
- Publishing makes your chosen content public. Do not include private information.

NEXT IMPROVEMENTS
- Replace the abstract CSS project artwork with your own finished campaign visuals.
- Add one strong case study for UrbanVibe: brief, audience insight, big idea, headline options, final ad and what you learned.
- Add a downloadable CV after you have checked it carefully.
